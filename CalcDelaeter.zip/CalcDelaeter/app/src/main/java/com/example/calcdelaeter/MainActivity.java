package com.example.calcdelaeter;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ListActivity {

    String list[] = {"plus", "moins", "multiplié", "divisé"};
    String operator = "nothing";
    EditText valeur1;
    EditText valeur2;
    TextView resultat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultat = findViewById(R.id.txt);
        valeur1 = findViewById(R.id.editText1);
        valeur2 = findViewById(R.id.editText2);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_single_choice,list);

        setListAdapter(adapter);

        ListView lv = getListView();

        lv.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = (String) parent.getItemAtPosition(position);
                operator = item;
            }
        });

    }

    public void leaveButton(View view) {
        finish();
    }

    public void calculate(View view) {

        if(valeur1.getText().toString().trim().length() == 0 || valeur2.getText().toString().trim().length() == 0){
            Toast.makeText(MainActivity.this, "Entrez les valeurs d'abord", Toast.LENGTH_SHORT).show();
        }
        else {
            float value1 = Float.parseFloat(valeur1.getText().toString());
            float value2 = Float.parseFloat(valeur2.getText().toString());
            String str = "error";

            if(operator == "divisé" && value2 == 0) {
                Toast.makeText(MainActivity.this, "Division par 0 impossible", Toast.LENGTH_SHORT).show();
            }
            else {
                if (operator == "nothing" || operator == "plus") {
                    str = Float.toString(value1 + value2);
                } else if (operator == "moins") {
                    str = Float.toString(value1 - value2);
                } else if (operator == "multiplié") {
                    str = Float.toString(value1 * value2);
                } else if (operator == "divisé") {
                    str = Float.toString(value1 / value2);
                }
                resultat.setText(str);
            }
        }
    }


    public void raz(View view) {
        valeur1.setText("");
        valeur2.setText("");
        resultat.setText("");
    }
}